# Excercise files: 

Open the below files to continue with this excercise: 

- [get_pet_labels.py](../data/get_pet_labels.py)

